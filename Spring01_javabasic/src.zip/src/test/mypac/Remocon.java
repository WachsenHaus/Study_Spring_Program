package test.mypac;

public interface Remocon {
	public void up();
	public void down();

}
