package test.mypac;

public class WeaponImpl implements Weapon{

	@Override
	public void attack() {
		// TODO Auto-generated method stub
		System.out.println("공격");
	}
	
	
	
	
}
