package test.mypac;

public interface Weapon {
	public void attack(); 
}
