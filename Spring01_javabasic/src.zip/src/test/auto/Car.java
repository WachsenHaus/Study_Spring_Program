package test.auto;

public class Car {
	//필드
	private Engine engine;
	
	//생성자
	public Car(Engine engine) {
		this.engine = engine;
	}
}
